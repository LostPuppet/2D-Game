using UnityEngine;

[CreateAssetMenu(fileName = "GameData", menuName = "ScriptableObjects/GameData", order = 1)]
public class GameData : ScriptableObject
{
    public float currentTime;
    public int currentLevel;

    public void SetLevel(int level)
    {
        currentLevel = level;
    }

    public void Tick(float deltaTime)
    {
        currentTime += deltaTime;
    }

    public void ResetTime()
    {
        currentTime = 0f;
    }
}