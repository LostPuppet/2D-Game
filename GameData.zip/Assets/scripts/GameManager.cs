using UnityEngine;

public class GameManager : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        gameData.SetLevel(0);
        gameData.ResetTime();
    }

    // Update is called once per frame
    public GameData gameData;

    void Update()
    {
        gameData.Tick(Time.deltaTime);
    }
}
